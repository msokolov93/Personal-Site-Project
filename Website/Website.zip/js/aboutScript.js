var aboutText = "This website was designed as a digital creative portfolio \n and showoff for learning new programming skills (html5 canvas) \n \n What always interested me the most - \n means of communications between a machine and a person. \n How to make it easier for the person to get involved in this communication? \n \n I've worked with clouds, web apps, design of interfaces, \n and even tried to program native mobile application once. \n \n I'm looking for the right people to make great products with. ";

function startAboutScene(){	
	document.getElementById("canvascontainer").style.display = "none";
	document.getElementById("aboutcontainer").style.display = "block";
	document.body.style.backgroundColor = "#000";
	animateAboutScene();
}

function animateAboutScene(){
	
}